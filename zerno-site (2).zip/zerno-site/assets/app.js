(function () {
  "use strict";
  var doc = document;

  // Мобильное меню
  var burger = doc.querySelector(".burger");
  var nav = doc.getElementById("nav");
  if (burger && nav) {
    burger.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      burger.setAttribute("aria-expanded", open ? "true" : "false");
      burger.setAttribute("aria-label", open ? "Закрыть меню сайта" : "Открыть меню сайта");
    });
    nav.addEventListener("click", function (e) {
      if (e.target.tagName === "A") {
        nav.classList.remove("open");
        burger.setAttribute("aria-expanded", "false");
      }
    });
  }

  // Тень у шапки после прокрутки
  var top = doc.querySelector(".top");
  if (top) {
    var onScroll = function () {
      if (window.scrollY > 8) top.classList.add("scrolled");
      else top.classList.remove("scrolled");
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  // Появление блоков. Если наблюдатель не сработал, показываем всё принудительно.
  var items = [].slice.call(doc.querySelectorAll(".rv"));
  if (!items.length) return;

  var showAll = function () {
    for (var i = 0; i < items.length; i++) items[i].classList.add("in");
  };

  if (!doc.documentElement.classList.contains("js-rv") || !("IntersectionObserver" in window)) {
    showAll();
    return;
  }

  var worked = false;
  var io = new IntersectionObserver(
    function (entries) {
      entries.forEach(function (entry, idx) {
        if (!entry.isIntersecting) return;
        worked = true;
        var el = entry.target;
        el.style.transitionDelay = Math.min(idx, 3) * 70 + "ms";
        el.classList.add("in");
        io.unobserve(el);
      });
    },
    { rootMargin: "0px 0px -8% 0px", threshold: 0.05 }
  );
  items.forEach(function (el) {
    io.observe(el);
  });

  // Страховка: если за 1,5 с ничего не показалось, снимаем скрытие
  window.setTimeout(function () {
    if (!worked) {
      io.disconnect();
      showAll();
    }
  }, 1500);

  // Страховка на случай печати или снимка страницы целиком
  window.addEventListener("beforeprint", showAll);
})();
